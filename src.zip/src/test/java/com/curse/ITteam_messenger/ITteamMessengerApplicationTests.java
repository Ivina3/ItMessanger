package com.curse.ITteam_messenger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ITteamMessengerApplicationTests {

	@Test
	void contextLoads() {
	}

}
