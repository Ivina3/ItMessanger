package com.curse.ITteam_messenger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ITteamMessengerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ITteamMessengerApplication.class, args);
	}

}
