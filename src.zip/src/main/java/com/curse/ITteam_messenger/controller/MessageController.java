package com.curse.ITteam_messenger.controller;

import com.curse.ITteam_messenger.dto.MessageDto;
import com.curse.ITteam_messenger.service.MessageService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/messages")
@RequiredArgsConstructor
public class MessageController {

    private final MessageService messageService;

    @GetMapping("/chat/{chatId}")
    public ResponseEntity<List<MessageDto>> getChatMessages(@PathVariable Long chatId, Authentication authentication) {
        String username = authentication.getName();
        return ResponseEntity.ok(messageService.getChatMessages(chatId, username));
    }

    @PostMapping
    public ResponseEntity<MessageDto> sendMessage(@RequestBody MessageDto messageDto, Authentication authentication) {
        String username = authentication.getName();
        return ResponseEntity.ok(messageService.sendMessage(messageDto, username));
    }
}

