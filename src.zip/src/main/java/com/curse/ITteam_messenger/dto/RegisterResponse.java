package com.curse.ITteam_messenger.dto;

import lombok.Data;

@Data
public class RegisterResponse {
    private String message;
} 