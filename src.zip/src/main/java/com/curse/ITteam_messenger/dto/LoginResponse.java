package com.curse.ITteam_messenger.dto;

import lombok.Data;

@Data
public class LoginResponse {
    private String token;
    private String username;
} 