package com.curse.ITteam_messenger.dto;

import lombok.Data;

@Data
public class MessageRequest {
    private String content;
}