package com.curse.ITteam_messenger.service.impl;

import com.curse.ITteam_messenger.dto.MessageDto;
import com.curse.ITteam_messenger.model.Chat;
import com.curse.ITteam_messenger.model.Message;
import com.curse.ITteam_messenger.model.User;
import com.curse.ITteam_messenger.repository.ChatRepository;
import com.curse.ITteam_messenger.repository.MessageRepository;
import com.curse.ITteam_messenger.repository.UserRepository;
import com.curse.ITteam_messenger.service.MessageService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class MessageServiceImpl implements MessageService {

    private final MessageRepository messageRepository;
    private final UserRepository userRepository;
    private final ChatRepository chatRepository;

    @Override
    @Transactional(readOnly = true)
    public List<MessageDto> getChatMessages(Long chatId, String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Chat chat = chatRepository.findById(chatId)
                .orElseThrow(() -> new RuntimeException("Chat not found"));

        if (!chat.getUsers().contains(user)) {
            throw new RuntimeException("User is not a member of this chat");
        }

        return messageRepository.findByChatIdOrderByCreatedAtAsc(chatId).stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public MessageDto sendMessage(MessageDto messageDto, String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Chat chat = chatRepository.findById(messageDto.getChatId())
                .orElseThrow(() -> new RuntimeException("Chat not found"));

        if (!chat.getUsers().contains(user)) {
            throw new RuntimeException("User is not a member of this chat");
        }

        Message message = new Message();
        message.setContent(messageDto.getContent());
        message.setSender(user);
        message.setChat(chat);

        Message savedMessage = messageRepository.save(message);
        return convertToDto(savedMessage);
    }

    private MessageDto convertToDto(Message message) {
        MessageDto dto = new MessageDto();
        dto.setId(message.getId());
        dto.setContent(message.getContent());
        dto.setSenderUsername(message.getSender().getUsername());
        dto.setChatId(message.getChat().getId());
        dto.setCreatedAt(message.getCreatedAt());
        return dto;
    }
} 