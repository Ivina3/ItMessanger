package com.curse.ITteam_messenger.service;

import com.curse.ITteam_messenger.dto.MessageDto;
import java.util.List;

public interface MessageService {
    List<MessageDto> getChatMessages(Long chatId, String username);
    MessageDto sendMessage(MessageDto messageDto, String username);
}
